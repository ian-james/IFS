int i = 0;

int * m = malloc(int);

int arr[10];

a[10] = 0;

return 0;
